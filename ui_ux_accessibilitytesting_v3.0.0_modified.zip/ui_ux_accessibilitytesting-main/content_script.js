console.log("Accessibility Scanner content script loaded");

(async function injectAxe() {
  if (window.axe) return;
  try {
    const resp = await chrome.runtime.sendMessage({ type: "INJECT_AXE" });
    if (resp?.ok) console.log("AXE injected");
    else console.warn("AXE injection failed", resp?.error);
  } catch (e) {
    console.warn("AXE inject error", e);
  }
})();

function cssEscape(value) {
  if (window.CSS?.escape) return window.CSS.escape(String(value));
  return String(value).replace(/([#.;:[\],=+*~>\s])/g, "\\$1");
}

function generateSelector(el) {
  if (!el || el.nodeType !== 1) return "";
  if (el.id) return `#${cssEscape(el.id)}`;
  const parts = [];
  let current = el;
  while (current && current.nodeType === 1 && current !== document.documentElement) {
    let part = current.tagName.toLowerCase();
    const classes = typeof current.className === "string"
      ? current.className.trim().split(/\s+/).filter(Boolean).slice(0, 2)
      : [];
    if (classes.length) part += classes.map((c) => `.${cssEscape(c)}`).join("");
    const parent = current.parentElement;
    if (parent) {
      const sameTag = Array.from(parent.children).filter((x) => x.tagName === current.tagName);
      if (sameTag.length > 1) part += `:nth-of-type(${sameTag.indexOf(current) + 1})`;
    }
    parts.unshift(part);
    current = parent;
  }
  return parts.join(" > ");
}

function isVisible(el) {
  if (!el) return false;
  const style = window.getComputedStyle(el);
  return !!style && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0" && el.getClientRects().length > 0;
}

function isDisabled(el) {
  return !!(el?.disabled || el?.hasAttribute("disabled") || el?.getAttribute("aria-disabled") === "true");
}

function getHtmlSnippet(el) {
  try { return el.outerHTML || el.textContent || ""; } catch { return ""; }
}

function addIssue(issues, data) {
  issues.push({
    wcag: "",
    level: "",
    category: "General",
    confidence: "High",
    ...data,
    selector: data.selector || generateSelector(data.element),
    html: data.html || getHtmlSnippet(data.element),
  });
}

function getInteractiveElements(root = document) {
  const selector = [
    "a[href]", "button", "input", "textarea", "select", "summary", "audio[controls]", "video[controls]",
    "[contenteditable=\"true\"]", "[tabindex]", "[role=button]", "[role=link]", "[role=checkbox]", "[role=radio]",
    "[role=tab]", "[role=menuitem]", "[role=option]", "[role=combobox]", "[role=listbox]", "[role=slider]",
    "[role=spinbutton]", "[role=switch]", "[role=treeitem]", "[role=gridcell]", "[role=grid]", "[role=tree]",
    "[onclick]", "[onmousedown]", "[onmouseup]"
  ].join(",");
  return Array.from(root.querySelectorAll(selector));
}

function isActuallyFocusable(el) {
  if (!el || !isVisible(el) || isDisabled(el)) return false;
  if (el.matches("input,select,textarea,button") && el.hasAttribute("hidden")) return false;
  if (el.matches("a[href],button,input,textarea,select,summary,[contenteditable=true],[tabindex],[role=button],[role=link],[role=checkbox],[role=radio],[role=tab],[role=menuitem],[role=option],[role=combobox],[role=listbox],[role=slider],[role=spinbutton],[role=switch],[role=treeitem],[role=gridcell]")) {
    return el.tabIndex >= 0;
  }
  return false;
}

function getFocusableElements() {
  return getInteractiveElements(document).filter(isActuallyFocusable);
}

function getAccessibleName(el) {
  if (!el) return "";
  const ariaLabel = el.getAttribute("aria-label");
  if (ariaLabel?.trim()) return ariaLabel.trim();
  const labelledBy = el.getAttribute("aria-labelledby");
  if (labelledBy) {
    const text = labelledBy.split(/\s+/).map((id) => document.getElementById(id)?.textContent || "").join(" ").trim();
    if (text) return text;
  }
  if (el.labels?.length) {
    const text = Array.from(el.labels).map((x) => x.textContent || "").join(" ").trim();
    if (text) return text;
  }
  if (el.getAttribute("alt")?.trim()) return el.getAttribute("alt").trim();
  if (el.getAttribute("title")?.trim()) return el.getAttribute("title").trim();
  return (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
}

function hasKeyboardHandler(el) {
  if (!el) return false;
  const inline = ["keydown", "keyup", "keypress"].some((x) => el.getAttribute(`on${x}`));
  const role = (el.getAttribute("role") || "").toLowerCase();
  const native = el.matches("button,a[href],input,select,textarea,summary") || ["checkbox","radio","tab","option","combobox","listbox","slider","spinbutton","switch","treeitem"].includes(role);
  return inline || native;
}

function getFocusStyleSnapshot(el) {
  const style = window.getComputedStyle(el);
  return {
    outlineStyle: style.outlineStyle,
    outlineWidth: style.outlineWidth,
    outlineColor: style.outlineColor,
    boxShadow: style.boxShadow,
    borderTopColor: style.borderTopColor,
    borderRightColor: style.borderRightColor,
    borderBottomColor: style.borderBottomColor,
    borderLeftColor: style.borderLeftColor,
    backgroundColor: style.backgroundColor,
  };
}

function hasVisibleFocusIndicator(el, before) {
  if (!el || document.activeElement !== el) return false;
  const after = getFocusStyleSnapshot(el);
  const outlineVisible = after.outlineStyle !== "none" && parseFloat(after.outlineWidth || "0") > 0 && after.outlineColor !== "transparent";
  const shadowVisible = after.boxShadow && after.boxShadow !== "none";
  const borderChanged = before && ["borderTopColor","borderRightColor","borderBottomColor","borderLeftColor","backgroundColor"].some((k) => before[k] !== after[k]);
  return !!(outlineVisible || shadowVisible || borderChanged);
}

function restoreFocus(previous) {
  try { if (previous && typeof previous.focus === "function") previous.focus({ preventScroll: true }); } catch (_) {}
}

function captureElementImage(selector) {
  return new Promise((resolve) => {
    let el = null;
    try { el = document.querySelector(selector); } catch (_) {}
    if (!el) return resolve(null);
    el.scrollIntoView({ behavior: "auto", block: "center" });
    const rect = el.getBoundingClientRect();
    const scale = window.devicePixelRatio || 1;
    chrome.runtime.sendMessage({ type: "CAPTURE_SCREENSHOT" }, (resp) => {
      if (!resp?.ok) return resolve(null);
      const img = new Image();
      img.onload = () => {
        try {
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(rect.width * scale));
          canvas.height = Math.max(1, Math.round(rect.height * scale));
          const ctx = canvas.getContext("2d");
          ctx.drawImage(img, (rect.left + window.scrollX) * scale, (rect.top + window.scrollY) * scale, rect.width * scale, rect.height * scale, 0, 0, rect.width * scale, rect.height * scale);
          resolve(canvas.toDataURL("image/png"));
        } catch (err) { console.warn("Snapshot error:", err); resolve(null); }
      };
      img.onerror = () => resolve(null);
      img.src = resp.dataUrl;
    });
  });
}

function runCustomHeuristics() {
  const issues = [];

  document.querySelectorAll("img").forEach((img) => {
    if (!isVisible(img)) return;
    const role = (img.getAttribute("role") || "").toLowerCase();
    if (["presentation", "none"].includes(role) || img.getAttribute("aria-hidden") === "true") return;
    if (!img.getAttribute("alt")?.trim()) addIssue(issues, {
      rule: "image-alt", impact: "minor", wcag: "1.1.1", level: "A", category: "Images",
      description: "Image is missing an alternative text or an explicit decorative treatment.", element: img
    });
  });

  document.querySelectorAll("input, textarea, select, [role='textbox']").forEach((el) => {
    if (!isVisible(el) || el.type === "hidden") return;
    const labelled = getAccessibleName(el);
    if (!labelled) addIssue(issues, {
      rule: "form-label", impact: "serious", wcag: "1.3.1, 3.3.2, 4.1.2", level: "A", category: "Forms",
      description: "Form control does not have a detectable accessible name.", element: el
    });
  });

  document.querySelectorAll("[role='dialog'], dialog").forEach((el) => {
    if (!isVisible(el)) return;
    if (!getAccessibleName(el)) addIssue(issues, {
      rule: "dialog-name", impact: "serious", wcag: "4.1.2", level: "A", category: "ARIA",
      description: "Dialog is missing an accessible name.", element: el
    });
  });

  document.querySelectorAll("table").forEach((table) => {
    const headers = table.querySelectorAll("th, [role='columnheader'], [role='rowheader']");
    if (headers.length === 0) addIssue(issues, {
      rule: "table-headers", impact: "serious", wcag: "1.3.1", level: "A", category: "Tables",
      description: "Table has no detectable header cells.", element: table
    });
  });

  const ids = {};
  document.querySelectorAll("[id]").forEach((el) => { if (el.id) ids[el.id] = (ids[el.id] || 0) + 1; });
  Object.entries(ids).forEach(([id, count]) => {
    if (count > 1) addIssue(issues, {
      rule: "duplicate-id", impact: "serious", wcag: "4.1.1", level: "A", category: "Structure",
      description: `Duplicate id "${id}" found ${count} times.`, selector: `#${cssEscape(id)}`
    });
  });

  // Positive tabindex creates author-defined focus order and is a common source of WCAG 2.4.3 failures.
  document.querySelectorAll("[tabindex]").forEach((el) => {
    const value = Number(el.getAttribute("tabindex"));
    if (Number.isFinite(value) && value > 0) addIssue(issues, {
      rule: "positive-tabindex", impact: "serious", wcag: "2.4.3", level: "A", category: "Keyboard",
      description: `Positive tabindex=${value} can create an unexpected focus order. Prefer tabindex="0" with logical DOM order.`, element: el
    });
  });

  // Pointer-only custom controls.
  document.querySelectorAll("[onclick], [onmousedown], [onmouseup]").forEach((el) => {
    if (!isVisible(el)) return;
    const nativeInteractive = el.matches("a[href],button,input,select,textarea,summary");
    if (nativeInteractive) return;
    const role = (el.getAttribute("role") || "").toLowerCase();
    if (!role && el.tabIndex < 0) addIssue(issues, {
      rule: "keyboard-pointer-only", impact: "serious", wcag: "2.1.1", level: "A", category: "Keyboard",
      description: "Element has pointer interaction but no detectable keyboard focus/interaction semantics.", element: el
    });
  });

  // ARIA references.
  const ariaRefs = ["aria-labelledby","aria-describedby","aria-controls","aria-owns","aria-activedescendant","aria-details","aria-errormessage"];
  document.querySelectorAll("[aria-labelledby], [aria-describedby], [aria-controls], [aria-owns], [aria-activedescendant], [aria-details], [aria-errormessage]").forEach((el) => {
    ariaRefs.forEach((attr) => {
      const value = el.getAttribute(attr);
      if (!value) return;
      value.split(/\s+/).filter(Boolean).forEach((id) => {
        if (!document.getElementById(id)) addIssue(issues, {
          rule: "broken-aria-reference", impact: "serious", wcag: "4.1.2", level: "A", category: "ARIA",
          description: `${attr} references missing element id "${id}".`, element: el
        });
      });
    });
  });

  // Interactive elements that cannot be focused.
  document.querySelectorAll("a[href],button,input,textarea,select,summary,[role='button'],[role='link'],[role='checkbox'],[role='radio'],[role='tab'],[role='menuitem'],[role='option']").forEach((el) => {
    if (!isVisible(el) || isDisabled(el)) return;
    if (!isActuallyFocusable(el)) addIssue(issues, {
      rule: "not-focusable", impact: "serious", wcag: "2.1.1", level: "A", category: "Keyboard",
      description: "Interactive element is not keyboard focusable.", element: el
    });
  });

  return issues;
}

async function runKeyboardAudit() {
  const issues = [];
  const focusables = getFocusableElements();
  const previousFocus = document.activeElement;

  // Focus order analysis: positive tabindex and nested focusable controls.
  const positive = focusables.filter((el) => el.tabIndex > 0);
  if (positive.length > 1) {
    const domOrder = [...positive];
    const tabOrder = [...positive].sort((a,b) => a.tabIndex - b.tabIndex || domOrder.indexOf(a) - domOrder.indexOf(b));
    if (tabOrder.some((el, i) => el !== domOrder[i])) {
      addIssue(issues, {
        rule: "keyboard-focus-order", impact: "serious", wcag: "2.4.3", level: "A", category: "Keyboard", confidence: "High",
        description: "Positive tabindex values create a focus sequence different from DOM order. Review the resulting keyboard order for meaning and operability.", element: positive[0]
      });
    }
  }

  // Nested focusable controls are a strong signal of confusing keyboard navigation.
  focusables.forEach((el) => {
    const nested = Array.from(el.querySelectorAll("a[href],button,input,textarea,select,[tabindex],[role='button'],[role='link']")).filter((x) => x !== el && isActuallyFocusable(x));
    if (nested.length) addIssue(issues, {
      rule: "nested-focusable", impact: "moderate", wcag: "2.4.3", level: "A", category: "Keyboard",
      description: "Focusable control contains another focusable control; review for duplicate or confusing tab stops.", element: el
    });
  });

  // Detect visible focus by focusing controls one by one. This is an audit, not an activation test.
  const sample = focusables.slice(0, 150);
  for (const el of sample) {
    if (!document.contains(el) || !isVisible(el)) continue;
    let before = null;
    try {
      before = getFocusStyleSnapshot(el);
      el.focus({ preventScroll: true });
      // Force a style read after focus. Focus-visible is browser-dependent, so this is a confidence-based heuristic.
      const visible = hasVisibleFocusIndicator(el, before);
      const style = window.getComputedStyle(el);
      const outlineSuppressed = style.outlineStyle === "none" || parseFloat(style.outlineWidth || "0") === 0;
      const shadowSuppressed = !style.boxShadow || style.boxShadow === "none";
      const focusVisibleRule = el.matches(":focus-visible");
      if (!visible && outlineSuppressed && shadowSuppressed && !focusVisibleRule) addIssue(issues, {
        rule: "keyboard-focus-visible", impact: "serious", wcag: "2.4.7", level: "AA", category: "Keyboard", confidence: "Medium",
        description: "Focused element has no detectable outline, box-shadow, or other style change. Verify that a visible keyboard focus indicator is provided.", element: el
      });
    } catch (_) {}
  }

  // Role-based keyboard expectations.
  document.querySelectorAll("[role]").forEach((el) => {
    if (!isVisible(el)) return;
    const role = (el.getAttribute("role") || "").toLowerCase();
    const keyboardRoles = new Set(["button","link","checkbox","radio","switch","tab","menuitem","option","combobox","listbox","slider","spinbutton","treeitem"]);
    if (!keyboardRoles.has(role)) return;
    if (el.tabIndex < 0) return;
    if (!hasKeyboardHandler(el) && !el.matches("button,a[href],input,select,textarea")) addIssue(issues, {
      rule: "keyboard-operable-role", impact: "moderate", wcag: "2.1.1, 4.1.2", level: "A", category: "Keyboard", confidence: "Medium",
      description: `Element has ARIA role="${role}" but no detectable native or inline keyboard handler. Verify Enter/Space/Arrow/Escape behavior as appropriate for the widget.`, element: el
    });
  });

  // Scrollable regions that are not keyboard reachable.
  document.querySelectorAll("*").forEach((el) => {
    if (!isVisible(el)) return;
    const style = getComputedStyle(el);
    const scrollable = (style.overflowY === "auto" || style.overflowY === "scroll" || style.overflowX === "auto" || style.overflowX === "scroll") && (el.scrollHeight > el.clientHeight + 2 || el.scrollWidth > el.clientWidth + 2);
    if (scrollable && el.tabIndex < 0 && !el.matches("textarea,select,[role=listbox],[role=grid],[role=tree]")) addIssue(issues, {
      rule: "scrollable-region-keyboard", impact: "moderate", wcag: "2.1.1", level: "A", category: "Keyboard", confidence: "Medium",
      description: "Scrollable region is not keyboard focusable. Verify that keyboard users can reach and operate the scrollable content.", element: el
    });
  });

  // Same-origin iframes: report interactive frames so users know the scan boundary.
  document.querySelectorAll("iframe").forEach((frame) => {
    if (!isVisible(frame)) return;
    try {
      const doc = frame.contentDocument;
      if (doc) {
        const inner = doc.querySelectorAll("a[href],button,input,textarea,select,[tabindex],[role]").length;
        if (inner > 0) addIssue(issues, {
          rule: "iframe-keyboard-content", impact: "minor", wcag: "2.1.1", level: "A", category: "Keyboard", confidence: "High",
          description: `Iframe contains approximately ${inner} interactive/ARIA elements. Same-origin content should be scanned separately; cross-origin content cannot be inspected by this extension from the parent document.`, element: frame
        });
      }
    } catch (_) {
      addIssue(issues, {
        rule: "iframe-scan-boundary", impact: "minor", wcag: "2.1.1", level: "A", category: "Keyboard", confidence: "High",
        description: "Cross-origin iframe could not be inspected. Run the scanner within the iframe origin if accessibility testing is required.", element: frame
      });
    }
  });

  restoreFocus(previousFocus);
  return issues;
}

window._FULL_SCAN = async function (options = {}) {
  const results = { axe: {}, custom: [], keyboard: [], meta: {}, csv: [] };

  try {
    if (window.axe) {
      const axeResults = await window.axe.run(document, {
        runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"] }
      });
      results.axe = axeResults;
      for (const group of ["violations", "incomplete", "passes"]) {
        for (const issue of axeResults[group] || []) {
          for (const node of issue.nodes) {
            const selector = node.target?.[0];
            node.snapshot = selector ? await captureElementImage(selector) : null;
            results.csv.push({ Source: "AXE", Group: group, Rule: issue.id || "", Impact: issue.impact || "", Description: issue.help || issue.description || "", Selector: selector || "", HTML: node.html || "", WCAG: issue.tags?.filter((t) => /^wcag/.test(t)).join("; ") || "", Category: "AXE", Confidence: "High", Snapshot: node.snapshot || "" });
          }
        }
      }
    }
  } catch (e) { results.axeError = e.message; }

  results.custom = runCustomHeuristics();
  results.keyboard = await runKeyboardAudit();
  const combined = [...results.custom, ...results.keyboard];
  for (const c of combined) {
    c.snapshot = await captureElementImage(c.selector);
    results.csv.push({ Source: c.category === "Keyboard" ? "Keyboard" : "Custom", Group: c.category === "Keyboard" ? "keyboard" : "custom", Rule: c.rule, Impact: c.impact || "minor", Description: c.description, Selector: c.selector || "", HTML: c.html || "", WCAG: c.wcag || "", Level: c.level || "", Category: c.category || "General", Confidence: c.confidence || "High", Snapshot: c.snapshot || "" });
  }

  results.meta = { timestamp: Date.now(), url: location.href, title: document.title, scannerVersion: "3.0.0", axeAvailable: !!window.axe, keyboardChecks: results.keyboard.length };
  return { ok: true, results };
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "RUN_SCAN") {
    window._FULL_SCAN(msg.options).then((r) => sendResponse(r)).catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === "CAPTURE_SNIPPET") {
    captureElementImage(msg.selector).then((data) => sendResponse({ ok: true, dataUrl: data }));
    return true;
  }
});
