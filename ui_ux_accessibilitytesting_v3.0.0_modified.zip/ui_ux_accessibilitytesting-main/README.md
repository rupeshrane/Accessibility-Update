# Accessibility Scan v3.0.0

Chrome Manifest V3 accessibility scanner with AXE, custom heuristics, and a dedicated keyboard accessibility audit layer.

## Major upgrades in v3.0.0

### Keyboard accessibility
- Positive `tabindex` detection and focus-order warning
- Interactive controls that are not keyboard focusable
- Pointer-only custom controls (`onclick`, `mousedown`, `mouseup`)
- Keyboard-operable ARIA role checks
- Focusable controls nested inside other focusable controls
- Focus-visible heuristic using actual focus plus computed styles
- Scrollable-region keyboard reachability check
- Same-origin/cross-origin iframe scan-boundary reporting
- WCAG mappings for keyboard findings

### ARIA and structure
- Broken ARIA ID-reference detection for `aria-labelledby`, `aria-describedby`, `aria-controls`, `aria-owns`, `aria-activedescendant`, `aria-details`, and `aria-errormessage`
- Improved duplicate-ID handling with CSS escaping
- Improved accessible-name detection for custom form controls and dialogs

### Existing functionality retained
- AXE scanning
- Full-page snapshot workflow
- Custom heuristics
- CSV export
- PDF export
- Chrome MV3 service worker architecture

## Important testing note
The keyboard audit is intentionally a hybrid static/runtime audit. It programmatically focuses controls and inspects focus state, but it does **not** automatically activate every control with Enter/Space or simulate every complex widget interaction. Those interactions still require manual verification for complete WCAG conformance.

## Loading the extension
1. Extract this ZIP.
2. Open `chrome://extensions`.
3. Enable **Developer mode**.
4. Select **Load unpacked**.
5. Select the extracted `ui_ux_accessibilitytesting-main` folder.

## WCAG scope
The implementation is aligned to WCAG 2.2 concepts, especially keyboard accessibility, Focus Order (2.4.3), Focus Visible (2.4.7), and Focus Not Obscured (2.4.11). The bundled AXE engine remains the version shipped with the original project because this build environment cannot download a newer third-party binary.
