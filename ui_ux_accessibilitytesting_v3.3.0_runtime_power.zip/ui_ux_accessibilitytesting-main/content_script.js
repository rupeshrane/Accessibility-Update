console.log("Accessibility Scanner content script loaded");

(async function injectAxe() {
  if (window.axe) return;
  try {
    const resp = await chrome.runtime.sendMessage({ type: "INJECT_AXE" });
    if (!resp?.ok) console.warn("AXE injection failed", resp?.error);
  } catch (e) { console.warn("AXE inject error", e); }
})();

function cssEscape(value) {
  if (window.CSS?.escape) return CSS.escape(String(value));
  return String(value).replace(/[^a-zA-Z0-9_-]/g, (c) => `\\${c}`);
}

function generateSelector(el) {
  if (!el) return "";
  if (el.id) return `#${cssEscape(el.id)}`;
  const parts = [];
  let current = el;
  while (current && current.nodeType === 1 && parts.length < 8) {
    let part = current.tagName.toLowerCase();
    const cls = typeof current.className === "string" ? current.className.split(/\s+/)[0] : "";
    if (cls) part += "." + cls.replace(/[^a-z0-9_-]/gi, "");
    if (current.parentElement) {
      const siblings = [...current.parentElement.children].filter(x => x.tagName === current.tagName);
      if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
    }
    parts.unshift(part);
    current = current.parentElement;
  }
  return parts.join(" > ");
}

function isVisible(el) {
  if (!el || !(el instanceof Element)) return false;
  const style = getComputedStyle(el);
  const rect = el.getBoundingClientRect();
  return style.display !== "none" && style.visibility !== "hidden" && parseFloat(style.opacity || "1") > 0 && rect.width > 0 && rect.height > 0;
}

function isDisabled(el) {
  return el.hasAttribute("disabled") || el.getAttribute("aria-disabled") === "true" || el.closest("fieldset[disabled]");
}

function getHtmlSnippet(el) {
  try { return (el.outerHTML || el.textContent || "").slice(0, 4000); } catch { return ""; }
}

function issue(rule, impact, description, el, extra = {}) {
  return {
    source: "Custom",
    group: "custom",
    rule, impact, description,
    selector: typeof el === "string" ? el : generateSelector(el),
    html: typeof el === "string" ? "" : getHtmlSnippet(el),
    wcag: extra.wcag || "",
    level: extra.level || "",
    category: extra.category || "Accessibility",
    confidence: extra.confidence || "High",
    recommendation: extra.recommendation || "",
  };
}

function getAccessibleName(el) {
  if (!el) return "";
  const aria = el.getAttribute("aria-label");
  if (aria?.trim()) return aria.trim();
  const ids = el.getAttribute("aria-labelledby")?.trim().split(/\s+/).filter(Boolean) || [];
  if (ids.length) {
    const text = ids.map(id => document.getElementById(id)?.innerText || document.getElementById(id)?.textContent || "").join(" ").trim();
    if (text) return text;
  }
  if (el.matches("input,textarea,select") && el.id) {
    const label = document.querySelector(`label[for="${cssEscape(el.id)}"]`);
    if (label?.innerText?.trim()) return label.innerText.trim();
  }
  if (el.matches("img") && el.getAttribute("alt")?.trim()) return el.getAttribute("alt").trim();
  return (el.innerText || el.textContent || el.getAttribute("title") || "").trim().replace(/\s+/g, " ").slice(0, 200);
}

function getFocusableElements(root = document) {
  const selector = `a[href],area[href],button,input:not([type="hidden"]),select,textarea,summary,[contenteditable="true"],[tabindex]:not([tabindex="-1"]),[role="button"],[role="link"],[role="checkbox"],[role="radio"],[role="switch"],[role="tab"],[role="option"],[role="combobox"],[role="listbox"],[role="menuitem"],[role="slider"],[role="spinbutton"]`;
  return [...root.querySelectorAll(selector)].filter(el => isVisible(el) && !isDisabled(el) && el.tabIndex >= 0);
}

function captureElementImage(selector) {
  return new Promise((resolve) => {
    let el;
    try { el = document.querySelector(selector); } catch { return resolve(null); }
    if (!el) return resolve(null);
    el.scrollIntoView({ behavior: "auto", block: "center" });
    const rect = el.getBoundingClientRect();
    chrome.runtime.sendMessage({ type: "CAPTURE_SCREENSHOT" }, (resp) => {
      if (!resp?.ok) return resolve(null);
      const img = new Image();
      img.onload = () => {
        try {
          const scale = window.devicePixelRatio || 1;
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, rect.width * scale);
          canvas.height = Math.max(1, rect.height * scale);
          const ctx = canvas.getContext("2d");
          ctx.drawImage(img, (rect.left + scrollX) * scale, (rect.top + scrollY) * scale, rect.width * scale, rect.height * scale, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL("image/png"));
        } catch { resolve(null); }
      };
      img.src = resp.dataUrl;
    });
  });
}

function runCustomHeuristics() {
  const issues = [];

  // Images
  document.querySelectorAll("img").forEach(img => {
    if (!isVisible(img) || ["presentation", "none"].includes((img.getAttribute("role") || "").toLowerCase()) || img.getAttribute("aria-hidden") === "true") return;
    if (!img.getAttribute("alt")?.trim()) issues.push(issue("image-alt", "minor", "Image is missing alternative text.", img, { wcag: "1.1.1", level: "A", recommendation: "Provide meaningful alt text, or use an explicit decorative presentation when appropriate." }));
  });

  // Form labels + autocomplete
  document.querySelectorAll("input:not([type=hidden]), textarea, select, [role='textbox'], [role='combobox']").forEach(el => {
    if (!isVisible(el)) return;
    if (!getAccessibleName(el)) issues.push(issue("form-label", "serious", "Form control is missing an accessible name.", el, { wcag: "1.3.1, 3.3.2, 4.1.2", level: "A", recommendation: "Associate a visible label or provide a valid accessible name." }));
    if (el.matches("input,textarea,select") && ["text","email","tel","url","password"].includes((el.type || "").toLowerCase()) && !el.hasAttribute("autocomplete")) issues.push(issue("autocomplete-missing", "minor", "Text input has no autocomplete attribute.", el, { wcag: "1.3.5", level: "AA", recommendation: "Provide an appropriate autocomplete token when the field collects personal information." }));
  });

  // Dialogs
  document.querySelectorAll("[role='dialog'],[role='alertdialog'],dialog").forEach(el => {
    if (!isVisible(el)) return;
    if (!getAccessibleName(el)) issues.push(issue("dialog-name", "serious", "Dialog is missing an accessible name.", el, { wcag: "4.1.2", level: "A", recommendation: "Use aria-labelledby or aria-label with a meaningful name." }));
  });

  // Tables
  document.querySelectorAll("table").forEach(table => {
    const headers = table.querySelectorAll("th,[role='columnheader'],[role='rowheader']");
    if (!headers.length) issues.push(issue("table-headers", "serious", "Data table has no detectable header cells.", table, { wcag: "1.3.1", level: "A", recommendation: "Use appropriate th/header semantics and relationships for data tables." }));
    table.querySelectorAll("th").forEach(th => {
      if (th.hasAttribute("scope") || th.hasAttribute("id") || th.hasAttribute("headers")) return;
      const row = th.parentElement;
      if (row?.children?.length > 1) issues.push(issue("table-header-association", "minor", "Table header has no explicit scope or header relationship.", th, { wcag: "1.3.1", level: "A", confidence: "Medium", recommendation: "Use scope or explicit headers/id relationships when needed for complex tables." }));
    });
  });

  // Duplicate IDs + broken ARIA references
  const ids = new Map();
  document.querySelectorAll("[id]").forEach(el => ids.set(el.id, (ids.get(el.id) || 0) + 1));
  ids.forEach((count, id) => { if (count > 1) issues.push(issue("duplicate-id", "serious", `Duplicate id "${id}" found ${count} times.`, `[id="${cssEscape(id)}"]`, { wcag: "4.1.1", level: "A", recommendation: "Make each id unique and update dependent ARIA references." })); });

  const refs = ["aria-labelledby","aria-describedby","aria-controls","aria-owns","aria-activedescendant","aria-details","aria-errormessage"];
  document.querySelectorAll(refs.map(x => `[${x}]`).join(",")).forEach(el => {
    refs.forEach(attr => {
      const value = el.getAttribute(attr); if (!value) return;
      value.split(/\s+/).filter(Boolean).forEach(id => { if (!document.getElementById(id)) issues.push(issue("broken-aria-reference", "serious", `${attr} references missing id "${id}".`, el, { wcag: "4.1.2", level: "A", recommendation: "Ensure every ARIA ID reference resolves to an existing element." })); });
    });
  });

  // Keyboard and focus
  const interactive = [...document.querySelectorAll(`a,button,input,select,textarea,summary,[role='button'],[role='link'],[role='checkbox'],[role='radio'],[role='switch'],[role='tab'],[role='option'],[role='combobox'],[role='listbox'],[role='menuitem'],[role='slider'],[role='spinbutton'],[contenteditable='true']`)].filter(isVisible);
  interactive.forEach(el => {
    const native = /^(A|BUTTON|INPUT|SELECT|TEXTAREA|SUMMARY)$/.test(el.tagName);
    const role = el.getAttribute("role");
    if (!native && el.tabIndex < 0 && !isDisabled(el)) issues.push(issue("not-keyboard-focusable", "serious", "Interactive element is not keyboard focusable.", el, { wcag: "2.1.1", level: "A", category: "Keyboard", recommendation: "Use a native interactive element or provide a valid keyboard focus target." }));
    if (!native && ["button","link","checkbox","radio","switch","tab","option","menuitem"].includes(role) && !el.hasAttribute("tabindex")) issues.push(issue("aria-widget-no-tabindex", "serious", `ARIA ${role} has no explicit keyboard focus model.`, el, { wcag: "2.1.1, 4.1.2", level: "A", category: "Keyboard", confidence: "Medium", recommendation: "Implement the appropriate roving tabindex or tabindex=0 keyboard pattern." }));
    if (el.tabIndex > 0) issues.push(issue("positive-tabindex", "moderate", `Positive tabindex (${el.tabIndex}) may create an unexpected focus order.`, el, { wcag: "2.4.3", level: "A", category: "Keyboard", recommendation: "Prefer tabindex=0 or native focus order." }));
  });

  // Pointer-only handlers
  document.querySelectorAll("[onclick],[onmousedown],[onmouseup],[ondblclick]").forEach(el => {
    if (!isVisible(el)) return;
    const native = /^(A|BUTTON|INPUT|SELECT|TEXTAREA|SUMMARY)$/.test(el.tagName);
    if (!native && el.tabIndex < 0 && !el.hasAttribute("role")) issues.push(issue("pointer-only-control", "serious", "Element has a pointer interaction but no detectable keyboard interaction semantics.", el, { wcag: "2.1.1", level: "A", category: "Keyboard", confidence: "High", recommendation: "Use a native button/link or provide an appropriate role, focusability and keyboard handler." }));
  });

  // Focus-visible heuristic: inspect focused visible elements without activating them
  const original = document.activeElement;
  const focusables = getFocusableElements();
  focusables.slice(0, 200).forEach(el => {
    const before = getComputedStyle(el);
    const oldOutline = before.outlineStyle;
    const oldShadow = before.boxShadow;
    const oldBorder = before.borderColor;
    try { el.focus({ preventScroll: true }); } catch { el.focus(); }
    if (document.activeElement === el) {
      const focused = getComputedStyle(el);
      const noIndicator = focused.outlineStyle === "none" && focused.outlineWidth === "0px" && focused.boxShadow === "none" && focused.borderColor === oldBorder;
      if (noIndicator) issues.push(issue("focus-indicator-missing", "serious", "No obvious visual focus indicator was detected for this focusable element.", el, { wcag: "2.4.7, 2.4.11", level: "AA", category: "Keyboard", confidence: "Medium", recommendation: "Provide a persistent visible focus indicator, preferably with :focus-visible." }));
    }
  });
  try { if (original && original.isConnected) original.focus({ preventScroll: true }); } catch {}

  // Focus order metadata
  const focusablesNow = getFocusableElements();
  const positives = focusablesNow.filter(e => e.tabIndex > 0).sort((a,b) => a.tabIndex-b.tabIndex);
  if (positives.length) issues.push(issue("focus-order-positive-tabindex", "moderate", `${positives.length} elements participate in a custom positive tabindex order.`, positives[0], { wcag: "2.4.3", level: "A", category: "Keyboard", recommendation: "Remove positive tabindex values and use DOM order with tabindex=0 where necessary." }));

  // Headings
  const headings = [...document.querySelectorAll("h1,h2,h3,h4,h5,h6")].filter(isVisible);
  let last = 0;
  headings.forEach(h => { const n = Number(h.tagName.substring(1)); if (last && n > last + 1) issues.push(issue("heading-level-skip", "minor", `Heading level jumps from H${last} to H${n}.`, h, { wcag: "1.3.1", level: "A", confidence: "Medium", recommendation: "Use heading levels that reflect the document structure." })); last = n; });
  if (!document.querySelector("main,[role='main']")) issues.push(issue("missing-main-landmark", "moderate", "No main landmark was detected on the page.", "body", { wcag: "1.3.1", level: "A", confidence: "Medium", recommendation: "Identify the primary content area with main or role=main." }));

  // Skip link
  const hasSkip = [...document.querySelectorAll("a[href^='#']")].some(a => /skip|jump to/i.test(a.innerText || a.getAttribute("aria-label") || ""));
  if (!hasSkip && document.querySelector("header,nav,main")) issues.push(issue("skip-link-missing", "moderate", "No skip-to-content link was detected.", "body", { wcag: "2.4.1", level: "A", confidence: "Medium", recommendation: "Provide a keyboard-accessible mechanism to bypass repeated content." }));

  // Target size heuristic
  document.querySelectorAll("a,button,input[type='button'],input[type='submit'],[role='button'],[role='link']").forEach(el => {
    if (!isVisible(el) || isDisabled(el)) return;
    const r = el.getBoundingClientRect();
    if (r.width < 24 || r.height < 24) issues.push(issue("target-size", "moderate", `Interactive target is ${Math.round(r.width)}×${Math.round(r.height)} CSS pixels.`, el, { wcag: "2.5.8", level: "AA", category: "Touch/Pointer", confidence: "High", recommendation: "Provide at least a 24×24 CSS pixel target or sufficient spacing, unless an exception applies." }));
  });

  // Language
  const htmlLang = document.documentElement.getAttribute("lang");
  if (!htmlLang?.trim()) issues.push(issue("html-lang-missing", "serious", "Document does not declare a language.", document.documentElement, { wcag: "3.1.1", level: "A", recommendation: "Add a valid lang attribute to the html element." }));

  // Iframes / shadow DOM visibility to tester
  document.querySelectorAll("iframe").forEach(frame => {
    if (!isVisible(frame)) return;
    try { const doc = frame.contentDocument; if (!doc) issues.push(issue("cross-origin-iframe", "minor", "Iframe could not be inspected from this page context.", frame, { category: "Coverage", confidence: "High", recommendation: "Run the scanner inside the iframe origin or provide an accessible test hook." })); }
    catch { issues.push(issue("cross-origin-iframe", "minor", "Cross-origin iframe could not be inspected.", frame, { category: "Coverage", confidence: "High", recommendation: "Run the scanner within the iframe origin." })); }
  });

  // Scrollable regions that are not keyboard accessible
  document.querySelectorAll("*").forEach(el => {
    if (!isVisible(el)) return;
    const s = getComputedStyle(el);
    const scrollable = /(auto|scroll)/.test(s.overflowY) && el.scrollHeight > el.clientHeight + 4;
    if (scrollable && el.tabIndex < 0 && !["BODY","HTML"].includes(el.tagName)) issues.push(issue("scrollable-region-not-focusable", "moderate", "Scrollable region is not keyboard focusable.", el, { wcag: "2.1.1", level: "A", category: "Keyboard", confidence: "Medium", recommendation: "Make custom scrollable regions keyboard reachable when users need to operate them." }));
  });

  return dedupeIssues(issues);
}


function getVisibleDialogs() {
  return [...document.querySelectorAll("[role='dialog'],[role='alertdialog'],dialog")].filter(isVisible);
}

function getRole(el) {
  return (el.getAttribute("role") || "").toLowerCase();
}

function hasKeyboardHandler(el) {
  // We can reliably detect inline/property handlers, but not arbitrary addEventListener registrations.
  return !!(el.onkeydown || el.onkeyup || el.onkeypress || el.getAttribute("onkeydown") || el.getAttribute("onkeyup") || el.getAttribute("onkeypress"));
}

function runtimeInteractionAudit() {
  const issues = [];
  const add = (rule, impact, desc, el, extra = {}) => issues.push(issue(rule, impact, desc, el, extra));

  // 1. Custom controls: keyboard semantics must be explicitly represented.
  document.querySelectorAll("[role='button'],[role='link'],[role='checkbox'],[role='radio'],[role='switch'],[role='tab'],[role='menuitem']").forEach(el => {
    if (!isVisible(el) || isDisabled(el)) return;
    const role = getRole(el);
    const native = /^(BUTTON|A|INPUT)$/.test(el.tagName);
    if (!native && el.tabIndex < 0) return; // already reported by static keyboard checks
    if (!native && (el.hasAttribute("onclick") || el.onclick) && !hasKeyboardHandler(el) && ["button","link","menuitem"].includes(role)) {
      add("pointer-only-custom-control", "serious", `Custom ${role} has pointer activation but no detectable keyboard handler. A synthetic keyboard probe cannot prove operation safely, so keyboard activation needs verification.`, el, {
        wcag: "2.1.1, 4.1.2", level: "A", category: "Keyboard", confidence: "Medium",
        recommendation: "Use a native control where possible, or implement and test the applicable Enter/Space keyboard interaction pattern."
      });
    }
  });

  // 2. Dialog runtime state: open modal dialogs should own focus.
  getVisibleDialogs().forEach(dialog => {
    const modal = dialog.getAttribute("aria-modal") === "true" || dialog.tagName.toLowerCase() === "dialog";
    if (!modal) return;
    const focusables = getFocusableElements(dialog);
    if (!focusables.length) {
      add("dialog-no-focusable-content", "serious", "Visible modal dialog contains no keyboard-focusable content.", dialog, {
        wcag: "2.1.1, 2.4.3, 4.1.2", level: "A", category: "Keyboard", confidence: "High",
        recommendation: "Provide a logical keyboard entry point and operable controls inside the dialog."
      });
      return;
    }
    if (!dialog.contains(document.activeElement)) {
      add("modal-focus-not-contained", "serious", "Visible modal dialog is not currently containing keyboard focus.", dialog, {
        wcag: "2.4.3", level: "A", category: "Keyboard", confidence: "Medium",
        recommendation: "When a modal opens, move focus into it and keep keyboard focus within the modal until it closes."
      });
    }
    if (modal && !dialog.hasAttribute("aria-modal") && dialog.tagName.toLowerCase() !== "dialog") {
      add("modal-missing-aria-modal", "moderate", "Dialog appears modal but does not expose aria-modal=true.", dialog, {
        wcag: "4.1.2", level: "A", category: "ARIA", confidence: "Medium",
        recommendation: "For an actual modal dialog, expose aria-modal=true and implement the complete modal keyboard pattern."
      });
    }
  });

  // 3. ARIA widget structure and keyboard-pattern readiness.
  document.querySelectorAll("[role='tablist']").forEach(list => {
    const tabs = [...list.querySelectorAll("[role='tab']")].filter(isVisible);
    if (!tabs.length) return;
    const selected = tabs.filter(t => t.getAttribute("aria-selected") === "true");
    const active = tabs.filter(t => t.tabIndex === 0);
    if (selected.length === 0) add("tablist-no-selected-tab", "moderate", "Visible tablist has no tab with aria-selected=true.", list, { wcag: "4.1.2", level: "A", category: "Keyboard", confidence: "Medium", recommendation: "Expose the active tab with aria-selected and implement the applicable arrow-key tab pattern." });
    if (active.length !== 1) add("tablist-roving-tabindex", "moderate", `Tablist has ${active.length} tabs with tabindex=0; a roving tabindex pattern normally keeps one active tab in the tab sequence.`, list, { wcag: "2.1.1, 2.4.3", level: "A", category: "Keyboard", confidence: "Medium", recommendation: "Implement a consistent tablist keyboard model with one entry point and arrow-key navigation. Verify Home/End behavior where supported." });
  });

  document.querySelectorAll("[role='listbox']").forEach(list => {
    const options = [...list.querySelectorAll("[role='option']")].filter(isVisible);
    if (!options.length) return;
    const selected = options.filter(o => o.getAttribute("aria-selected") === "true");
    if (selected.length > 1 && list.getAttribute("aria-multiselectable") !== "true") add("listbox-multiple-selected", "moderate", "Listbox exposes multiple selected options without aria-multiselectable=true.", list, { wcag: "4.1.2", level: "A", category: "ARIA", confidence: "High", recommendation: "Expose the correct selection model and implement the applicable arrow-key interaction pattern." });
  });

  document.querySelectorAll("[role='combobox']").forEach(combo => {
    if (!isVisible(combo)) return;
    const controls = combo.getAttribute("aria-controls");
    if (controls && !document.getElementById(controls)) add("combobox-broken-controls", "serious", `Combobox aria-controls references missing id "${controls}".`, combo, { wcag: "4.1.2", level: "A", category: "ARIA", confidence: "High", recommendation: "Ensure aria-controls points to the actual popup/listbox element." });
    if (!combo.hasAttribute("aria-expanded")) add("combobox-expanded-missing", "moderate", "Combobox does not expose aria-expanded state.", combo, { wcag: "4.1.2", level: "A", category: "ARIA", confidence: "High", recommendation: "Expose whether the combobox popup is expanded and keep the state synchronized." });
  });

  // 4. Keyboard-only review markers for interactions that cannot be safely activated automatically.
  document.querySelectorAll("[role='menu'],[role='menubar'],[role='tree'],[role='grid'],[role='treegrid'],[role='slider']").forEach(el => {
    if (!isVisible(el)) return;
    add("complex-widget-keyboard-review", "minor", `Complex ${getRole(el)} widget requires keyboard interaction verification; automated DOM inspection cannot safely prove its complete arrow-key/Home/End/Escape behavior.`, el, {
      wcag: "2.1.1, 2.4.3, 4.1.2", level: "A", category: "Keyboard", confidence: "High",
      recommendation: "Verify the widget with keyboard-only testing: Tab, Enter/Space, Arrow keys, Home/End and Escape as applicable. Confirm focus remains visible and the state changes are announced."
    });
  });

  // 5. Fixed/sticky overlays that can obscure focused controls.
  const overlays = [...document.querySelectorAll("*")].filter(el => {
    if (!isVisible(el)) return false;
    const pos = getComputedStyle(el).position;
    return pos === "fixed" || pos === "sticky";
  });
  const focused = document.activeElement;
  if (focused && focused !== document.body && isVisible(focused)) {
    const fr = focused.getBoundingClientRect();
    const centerX = fr.left + Math.min(fr.width / 2, Math.max(fr.width / 2, 1));
    const centerY = fr.top + Math.min(fr.height / 2, Math.max(fr.height / 2, 1));
    overlays.forEach(overlay => {
      if (overlay === focused || overlay.contains(focused)) return;
      const r = overlay.getBoundingClientRect();
      if (centerX >= r.left && centerX <= r.right && centerY >= r.top && centerY <= r.bottom) {
        add("focused-element-obscured", "serious", "The currently focused element appears to be covered by a fixed/sticky element.", focused, { wcag: "2.4.11", level: "AA", category: "Keyboard", confidence: "Medium", recommendation: "Ensure focused controls remain visible and are not obscured by fixed or sticky content." });
      }
    });
  }

  return issues;
}

async function dynamicContentAudit(waitMs = 500) {
  const changes = [];
  const observer = new MutationObserver(mutations => {
    let added = 0;
    mutations.forEach(m => mutations.forEach ? null : null);
    mutations.forEach(m => { added += [...m.addedNodes].filter(n => n.nodeType === 1).length; });
    if (added) changes.push(added);
  });
  try {
    observer.observe(document.documentElement, { subtree: true, childList: true });
    await new Promise(resolve => setTimeout(resolve, Math.max(100, waitMs)));
  } finally { observer.disconnect(); }
  return changes.reduce((a,b) => a+b, 0);
}

function dedupeIssues(issues) {
  const seen = new Set();
  return issues.filter(x => { const key = `${x.rule}|${x.selector}|${x.description}`; if (seen.has(key)) return false; seen.add(key); return true; });
}

window._FULL_SCAN = async function(options = {}) {
  const results = { axe: {}, custom: [], meta: {}, csv: [], coverage: {} };
  try {
    if (window.axe) {
      const axeResults = await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a","wcag2aa","wcag21a","wcag21aa"] } });
      results.axe = axeResults;
      for (const group of ["violations","incomplete","passes"]) {
        for (const item of axeResults[group] || []) {
          for (const node of item.nodes || []) {
            const selector = node.target?.[0] || "";
            node.snapshot = selector ? await captureElementImage(selector) : null;
            results.csv.push({ Source:"AXE", Group:group, Rule:item.id||"", Impact:item.impact||"", Description:item.help||item.description||"", Selector:selector, HTML:node.html||"", Snapshot:node.snapshot||"", WCAG:(item.tags||[]).filter(t=>/^wcag/.test(t)).join(";"), Level:(item.tags||[]).filter(t=>/^(wcag2|wcag21|wcag22)[a-z]+$/.test(t)).join(";"), Category:"AXE", Confidence:"High", Recommendation:item.helpUrl||"" });
          }
        }
      }
    }
  } catch(e) { results.axeError = e.message; }

  results.custom = runCustomHeuristics();

  // Safe runtime/state audit. We intentionally do not click arbitrary controls because that can submit forms or trigger destructive actions.
  const dynamicAdded = await dynamicContentAudit(Math.min(Number(options.dynamicWaitMs || 500), 1500));
  results.custom = dedupeIssues(results.custom.concat(runtimeInteractionAudit()));
  for (const c of results.custom) {
    c.snapshot = await captureElementImage(c.selector);
    results.csv.push({ Source:"Custom", Group:"custom", Rule:c.rule, Impact:c.impact||"minor", Description:c.description, Selector:c.selector, HTML:c.html||"", Snapshot:c.snapshot||"", WCAG:c.wcag||"", Level:c.level||"", Category:c.category||"Accessibility", Confidence:c.confidence||"High", Recommendation:c.recommendation||"" });
  }

  results.coverage = {
    keyboard: true,
    focus: true,
    ariaReferences: true,
    semanticStructure: true,
    touchTarget: true,
    sameOriginIframes: "attempted",
    crossOriginIframes: "reported",
    dynamicInteraction: dynamicAdded > 0 ? `observed ${dynamicAdded} DOM node additions during scan` : "no DOM additions observed during runtime window",
    manualReviewRequired: ["complex widget behavior","meaningfulness of alternative text","logical focus sequence","dynamic modal workflows"]
  };
  results.meta = { timestamp: Date.now(), url: location.href, title: document.title, scannerVersion: "3.3.0", wcagTarget: "WCAG 2.2" };
  return { ok:true, results };
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "RUN_SCAN") { window._FULL_SCAN(msg.options).then(sendResponse).catch(e => sendResponse({ok:false,error:e.message})); return true; }
  if (msg.type === "CAPTURE_SNIPPET") { captureElementImage(msg.selector).then(data => sendResponse({ok:true,dataUrl:data})); return true; }
});
